#' @param predictor [Predictor]\cr
#'   The object (created with `Predictor$new()`) holding the machine
#'   learning model and the data.
