#' Make machine learning models and predictions interpretable
#'
#' The iml package provides tools to analyze machine learning models and predictions.
#'
# > [1] "_PACKAGE"

#' @import R6
#' @import checkmate
#' @import future 
NULL
