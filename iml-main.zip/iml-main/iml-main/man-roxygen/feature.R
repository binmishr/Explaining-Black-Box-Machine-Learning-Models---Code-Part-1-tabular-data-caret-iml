#' @param feature (`character(1)` | `character(2)` | `numeric(1)` |
#'   `numeric(2)`)\cr
#'   The feature name or index for which to compute the effects.
